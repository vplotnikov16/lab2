import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.StaleProxyException;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

public class Client {
    static void main(String[] args) {
        Runtime rt = Runtime.instance();

        // Get main host from args or use localhost
        String mainHost = "localhost";
        if (args != null && args.length > 0) {
            mainHost = args[0];
        }

        Profile p = new ProfileImpl();
        p.setParameter(Profile.MAIN_HOST, mainHost);
        p.setParameter(Profile.MAIN_PORT, "1099");
        AgentContainer agentContainer = rt.createAgentContainer(p);

        try {
            // Add delay to ensure Server has created ComputerAgents
            System.out.println("Waiting 3 seconds for ComputerAgents to initialize...");
            Thread.sleep(3000);

            JsonNode tasks = new ObjectMapper().readTree(new File("src/Files/tasks.json"));
            Iterator<Map.Entry<String, JsonNode>> t = tasks.fields();

            int taskCount = 0;
            while (t.hasNext()) {
                Map.Entry<String, JsonNode> task = t.next();
                AgentController agent = agentContainer.createNewAgent(
                        task.getKey(),
                        "Agents.TaskAgent",
                        new Object[]{task.getValue().path("complexity").asText()}
                );
                agent.start();
                taskCount++;
            }

            System.out.println("Created " + taskCount + " TaskAgents. Waiting for distribution to complete...");

            // Wait for agents to complete distribution
            System.out.println("Keep this window open. Results will be written to src/Files/results.json");
            System.out.println("Waiting for 60 seconds...");
            Thread.sleep(60000);

            System.out.println("Distribution time completed. You can now check results.json");

        } catch (StaleProxyException | IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}